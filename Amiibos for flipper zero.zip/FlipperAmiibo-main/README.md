# FlipperAmiibo
A collection of FlipperZero NFC files that emulate Amiibo

## Installation

1. [Download](https://github.com/Gioman101/FlipperAmiibo/archive/refs/heads/main.zip) this repository as an archive
1. Extract the archive into the `nfc` directory on your Flipper's SD card.
